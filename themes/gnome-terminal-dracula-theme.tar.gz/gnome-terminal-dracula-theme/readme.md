# Dracula for [Gnome Terminal](https://wiki.gnome.org/Apps/Terminal)

> A dark theme for [Gnome Terminal](https://wiki.gnome.org/Apps/Terminal).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/gnome-terminal](https://draculatheme.com/gnome-terminal).

## Credits

This colorscheme is based on the well-known _Solarized Dark_ colorscheme for the Gnome Terminal.

## License

[MIT License](./LICENSE)